const register = (req,res)=>{

}
const login = (req,res)=>{

}
const logout = (req,res) =>{

}
const getProfile = (req,res) =>{

}

module.exports = {
    register,
    login,
    logout,
    getProfile
}